/**
 * StartExperiment.java
 * Created on: 1 mars 2016
 */
package eu.chorevolution.vsb.playgrounds.pubsub.mqtt.expriment;

/**
 * @author Georgios Bouloukakis (boulouk@gmail.com)
 *
 */
public class StartExperiment {

}
